// src/auth/auth.service.ts
import { Injectable } from '@nestjs/common';
import { UsersService } from 'src/users/users.service';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { JwtPayload } from './jwt-payload.interface';

@Injectable()
export class AuthService {
  constructor(
    private userService: UsersService,
    private jwtService: JwtService,
  ) {}

  async validateUser(email: string, password: string): Promise<any> {
    // Find user by email
    const user = await this.userService.findByEmail(email);

    // If user exists and password matches
    if (user && bcrypt.compareSync(password, user.password)) {
      const { password, ...result } = user;  // Remove password from result
      return result;
    }

    // If user doesn't exist or password doesn't match
    return null;
  }

  async login(data: { email: string, password: string }) {
    const user = await this.validateUser(data.email, data.password);

    if (!user) {
      throw new Error('Invalid credentials');
    }

    // Generate JWT Payload
    const payload: JwtPayload = { email: user.email, sub: user.id };

    // Generate JWT Token
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  async register(registerData: { first_name: string, last_name: string, email: string, password: string }) {
    return this.userService.register(registerData);
  }
}