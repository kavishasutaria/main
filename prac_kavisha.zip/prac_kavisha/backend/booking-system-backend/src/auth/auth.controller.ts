import { Controller, Post, Body } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

   @Post('register')
   async register(
     @Body('first_name') first_name: string,
     @Body('last_name') last_name: string,
     @Body('email') email: string,
     @Body('password') password: string,
   ) {
     const registrationData = { first_name, last_name, email, password };
     return this.authService.register(registrationData);
   }
 
   @Post('login')
   async login(@Body('email') email: string, @Body('password') password: string) {
     const loginData = { email, password };
     return this.authService.login(loginData);
   }
}
