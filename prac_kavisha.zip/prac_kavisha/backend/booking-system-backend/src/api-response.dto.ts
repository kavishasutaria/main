export class ApiResponse<T> {
    status: number;
    message: string;
    result: any;
  }
  