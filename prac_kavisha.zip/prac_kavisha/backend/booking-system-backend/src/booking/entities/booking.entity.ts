// src/booking/booking.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum BookingType {
  FULL_DAY = 'Full Day',
  HALF_DAY = 'Half Day',
  CUSTOM = 'Custom',
}

export enum BookingSlot {
  FIRST_HALF = 'First Half',
  SECOND_HALF = 'Second Half',
}

@Entity('bookings')
export class Booking {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  customer_name: string;

  @Column()
  customer_email: string;

  @Column()
  booking_date: string;

  @Column({ type: 'enum', enum: BookingType })
  booking_type: BookingType;

  @Column({ type: 'enum', enum: BookingSlot, nullable: true })
  booking_slot: BookingSlot;

  @Column({ nullable: true })
  booking_time: string; 

  @ManyToOne(() => User)
  user: User;
}
