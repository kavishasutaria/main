export class CreateBookingDto {
    booking_date:any;
    customer_name:any;
    customer_email: any;
    booking_type: any;
    booking_slot:any;
    booking_time:any;    
}
