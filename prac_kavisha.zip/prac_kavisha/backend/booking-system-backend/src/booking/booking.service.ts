import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateBookingDto } from './dto/create-booking.dto';
import { UpdateBookingDto } from './dto/update-booking.dto';
import { Booking } from './entities/booking.entity';
import { ApiResponse } from 'src/api-response.dto';


@Injectable()
export class BookingService {
  constructor(
    @InjectRepository(Booking)
    private bookingRepository: Repository<Booking>,
    @InjectRepository(Booking)
    private userRepository: Repository<Booking>,
  ) {}

  async checkDuplicateBooking(data: any) {
    const existingBooking = await this.bookingRepository.findOne({ where: { booking_date : data.booking_date, booking_type : data.booking_type } });
    if (existingBooking) {
      return {
        status: 200,
        message: 'Booking already exists for this date and type',
        result: {},
      };
    }
  }

  async createBooking(createBookingDto: CreateBookingDto): Promise<ApiResponse<Booking>> {
    try {
      const { customer_email, booking_date, booking_type, booking_slot, booking_time, customer_name } = createBookingDto;

      // Find user by email
      const user = await this.userRepository.findOne(createBookingDto.customer_email);
      if (!user) {
        return {
          status: 404,
          message: 'User with the given email not found',
          result: {},
        };
      }

      await this.checkDuplicateBooking(createBookingDto);

      const booking = this.bookingRepository.create({
        customer_email,
        customer_name,
        booking_date,
        booking_type,
        booking_slot,
        booking_time,
        user,
      });

      const newBooking = await this.bookingRepository.save(booking);
      return {
        status: 200,
        message: 'User with the given email not found',
        result: newBooking,
      };
    } catch (error) {
      // Handle any unexpected errors
      console.error(error);
      return {
        status: 500,
        message: 'Internal server error',
        result: {},
      };
    }
  }

}
