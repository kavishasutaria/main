import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { ApiResponse } from 'src/api-response.dto';


@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  async findByEmail(email: string): Promise<User | undefined> {
    return this.userRepository.findOne({ where: { email } });
  }

  async register(createUserDto: CreateUserDto): Promise<ApiResponse<User>> {
    const { first_name, last_name, email, password } = createUserDto;
  
    const existingUser = await this.userRepository.findOne({ where: { email } });
    if (existingUser) {
      return {
        status: 200,
        message: 'User already exists',
        result: {},
      };
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = this.userRepository.create({
      first_name,
      last_name,
      email,
      password: hashedPassword,
    });
  
    await this.userRepository.save(user);
  
    return {
      status: 201,
      message: 'User registered successfully',
      result: user,
    };
  }

  async login(data: any): Promise<any> {
    const user = await this.userRepository.findOne({ where: { email: data.email } });
    if (!user || !user.email_verified) {
      return {
        status: 200,
        message: 'User does not exist or not verified',
        result: {},
      };
    }

    const isPasswordValid = await bcrypt.compare(data.password, user.password);
    if (!isPasswordValid) {
      return {
        status: 200,
        message: 'Invalid credentials',
        result: {},
      };
    }

    return {
      status: 200,
      message: 'Login successful',
      result: { user },
    };
  }
}
