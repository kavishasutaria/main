import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL;

const apiRequest = async (method, url, data = null, token = null) => {
  try {
    const config = {
      method: method, 
      url: `${API_URL}${url}`, 
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }), 
      },
      data: data, 
    };

    const response = await axios(config);

    return response.data;
  } catch (error) {
    if (error.response) {
      console.error('API Error:', error.response.data);
      throw new Error(error.response.data.message || 'An error occurred while making the API request');
    } else if (error.request) {
      console.error('API Error:', error.request);
      throw new Error('No response received from the API');
    } else {
      console.error('API Error:', error.message);
      throw new Error(error.message);
    }
  }
};

export default apiRequest;
