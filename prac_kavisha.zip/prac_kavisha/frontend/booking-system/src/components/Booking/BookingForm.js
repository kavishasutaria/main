import React, { useState, useEffect } from 'react';
import apiRequest from '../../services/apiService';
import '../../styles/bookingForm.css';

function BookingForm() {
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_email: '',
    booking_date: '',
    booking_type: 'Full Day',
    booking_slot: '',
    booking_time: '',
  });
  const [error, setError] = useState('');
  const [bookings, setBookings] = useState([]);
  
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await apiRequest('Post', '/booking/createBooking');
        setBookings(response);
      } catch (err) {
        setError('Error loading bookings');
      }
    };
    
    fetchBookings();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const conflict = bookings.find(
      (booking) =>
        booking.booking_date === formData.booking_date &&
        ((formData.booking_type === 'Full Day' && booking.booking_type === 'Full Day') ||
        (formData.booking_type === 'Half Day' && booking.booking_slot === formData.booking_slot) ||
        (formData.booking_type === 'Custom' && booking.booking_time === formData.booking_time))
    );

    if (conflict) {
      setError('Booking conflict! Please choose another date or time.');
      return;
    }

    try {
      const response = await apiRequest('POST', '/bookings', formData);
      setFormData({
        customer_name: '',
        customer_email: '',
        booking_date: '',
        booking_type: 'Full Day',
        booking_slot: '',
        booking_time: '',
      });
      setError('');
      alert('Booking successful!');
    } catch (err) {
      setError('Error submitting booking');
    }
  };

  return (
    <div className="booking-form-container">
      <h2>Make a Booking</h2>
      {/* {error && <div className="error-message">{error}</div>} */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="customer_name"
          value={formData.customer_name}
          onChange={handleChange}
          placeholder="Customer Name"
          required
        />
        <input
          type="email"
          name="customer_email"
          value={formData.customer_email}
          onChange={handleChange}
          placeholder="Customer Email"
          required
        />
        <input
          type="date"
          name="booking_date"
          value={formData.booking_date}
          onChange={handleChange}
          required
        />
        <select
          name="booking_type"
          value={formData.booking_type}
          onChange={handleChange}
        >
          <option value="Full Day">Full Day</option>
          <option value="Half Day">Half Day</option>
          <option value="Custom">Custom</option>
        </select>

        {formData.booking_type === 'Half Day' && (
          <select
            name="booking_slot"
            value={formData.booking_slot}
            onChange={handleChange}
            required
          >
            <option value="First Half">First Half</option>
            <option value="Second Half">Second Half</option>
          </select>
        )}

        {formData.booking_type === 'Custom' && (
          <input
            type="time"
            name="booking_time"
            value={formData.booking_time}
            onChange={handleChange}
            required
          />
        )}

        <button type="submit">Submit Booking</button>
      </form>
    </div>
  );
}

export default BookingForm;
